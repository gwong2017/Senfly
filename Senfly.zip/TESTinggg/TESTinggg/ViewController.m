//
//  ViewController.m
//  TESTinggg
//
//  Created by Victor on 3/6/2017.
//  Copyright © 2017 Victor. All rights reserved.
//

#import "ViewController.h"
#import "JCDialPad.h"
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>


@interface ViewController () <JCDialPadDelegate>

@property (assign, nonatomic) NSInteger tapCount;
@property (strong, nonatomic) NSArray *audioTaxiArray;
@property (strong, nonatomic) NSArray *audioRestaurantArray;

@property (strong, nonatomic) NSArray *textTaxiArray;
@property (strong, nonatomic) NSArray *textRestaurantArray;

@property (strong, nonatomic) AVAudioPlayer *audioPlayer;

@property (strong, nonatomic) JCDialPad *pad;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.pad = [[JCDialPad alloc] initWithFrame:self.view.bounds];
    self.pad.buttons = [JCDialPad defaultButtons];
    self.pad.delegate = self;
    self.pad.formatTextToPhoneNumber = NO;
    [self.view addSubview:self.pad];
    
    self.tapCount = 0;
    
    self.audioTaxiArray = @[@"1-taxi-opening-n-ask-dest-press-1-2",
                            @"2-taxi-specify-dest-speak",
                            @"3-taxi-dest-set-confirm-press-1-2",
                            @"4-taxi-plz-hold-music",
                            @"5-taxi-finish-bye"];
    self.audioRestaurantArray = @[@"6-rest-opening-n-ask-name-speak",
                                  @"7-rest-enter-guest-num-press-pound",
                                  @"8-rest-booking-time-speak",
                                  @"9-rest-finish-bye"];
    
    self.textTaxiArray
    = @[@"Thank you for calling. Where would you like to go?", @"PRESS 1 to go back home.", @"PRESS 2 to specify a destination.",@"Please say your destination after beep:<Beeeeep>",@"Your destination is set. Are you at Cyberport 3? Press 1 for Yes. Press 2 for No.",@"Please hold.",@"Your ride is on its way! ",@"Have a nice day!"];
    
    self.textRestaurantArray
    = @[@"Thanks for calling.",@"Please say your restaurant name after the beep",@"Please enter the number of guests after the beep and press pound.",@"Please say your booking time.",@"Booking successful! The details will be shown on your screen.",@"Have a nice day!"];
    
    
    // TODO: initial audio here
    self.tapCount = 0;
    [self shouldInsertText:@""];
}

- (BOOL)shouldInsertText:(NSString *)text {
    dispatch_async(dispatch_get_main_queue(), ^(){
        if (![text isEqualToString:@"  "]) {
            [self playSound:@"dial"];
        }
    });
    
    // Dismiss button
    if ([text isEqualToString:@"  "]) {
        // dismiss the vc
        [self dismissViewControllerAnimated:YES completion:nil];
        
        if (self.scene == 0) {
            [self.dialPadViewDelegate changeScene:0];
        }
        if (self.scene == 1) {
            [self.dialPadViewDelegate changeScene:1];
        }
        
        return true;
    };
    
    // Taxi
    if (self.scene == 0) {
        [self playSoundTrack:self.audioTaxiArray[self.tapCount]];
        [self showText: _textTaxiArray[self.tapCount]];
        
        if (self.tapCount == self.audioTaxiArray.count - 1) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self dismissViewControllerAnimated:YES completion:nil];
                });
            });
        }
    }
    
    // Restaurant
    if (self.scene == 1) {
        [self playSoundTrack:self.audioRestaurantArray[self.tapCount]];
        [self showText: _textRestaurantArray[self.tapCount]];
        
        if (self.tapCount == self.audioRestaurantArray.count - 1) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self dismissViewControllerAnimated:YES completion:nil];
                });
            });
        }
    }
    
    self.tapCount += 1;
    return true;
}

- (BOOL)dialPad:(JCDialPad *)dialPad shouldInsertText:(NSString *)text forButtonPress:(JCPadButton *)button {
    
    return [self shouldInsertText:text];
    
        return true;
}

- (void)playSound:(NSString *)sound {
    dispatch_async(dispatch_get_main_queue(), ^(){
        SystemSoundID soundID;
        NSString *soundPath = [[NSBundle mainBundle] pathForResource:sound ofType:@"mp3"];
        NSURL *soundUrl = [NSURL fileURLWithPath:soundPath];
        AudioServicesCreateSystemSoundID ((__bridge CFURLRef)soundUrl, &soundID);
        AudioServicesPlaySystemSound(soundID);
    });
}

- (void)playSoundTrack:(NSString *)sound {
    dispatch_async(dispatch_get_main_queue(), ^(){
        NSString *soundFilePath = [[NSBundle mainBundle]pathForResource:sound ofType:@"mp3"];
        self.audioPlayer = [[AVAudioPlayer alloc]initWithContentsOfURL:[NSURL fileURLWithPath:soundFilePath] error:NULL];
        [self.audioPlayer play];
    });
}

-(void)showText:(NSString *)text {
    self.pad.transcription.text = text;
    self.pad.transcription.numberOfLines = 2;
    [self.pad.transcription sizeToFit];
}


@end
