//
//  AppDelegate.h
//  TESTinggg
//
//  Created by Victor on 3/6/2017.
//  Copyright © 2017 Victor. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

