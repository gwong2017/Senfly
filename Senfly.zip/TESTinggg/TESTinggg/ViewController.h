//
//  ViewController.h
//  TESTinggg
//
//  Created by Victor on 3/6/2017.
//  Copyright © 2017 Victor. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DialPadViewDelegate <NSObject>
- (void)changeScene:(NSInteger)scene;
@end

@interface ViewController : UIViewController

// 0 = call taxi, 1 = seat reservation
@property (assign, nonatomic) NSInteger scene;


@property (weak, nonatomic) id <DialPadViewDelegate> dialPadViewDelegate;

@end

