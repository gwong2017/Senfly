//
//  HomeIntroViewController.m
//  TESTinggg
//
//  Created by Victor on 3/6/2017.
//  Copyright © 2017 Victor. All rights reserved.
//

#import "HomeIntroViewController.h"
#import "ViewController.h"

#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>

@interface HomeIntroViewController () <DialPadViewDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *imageeView;

@property (strong, nonatomic) AVAudioPlayer *audioPlayer;

@end

@implementation HomeIntroViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}



- (IBAction)taxiButtonTapped:(id)sender {
    ViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"dialpad"];
    vc.scene = 0;
    vc.dialPadViewDelegate = self;
    [self presentViewController:vc animated:YES completion:nil];
}

- (IBAction)restaurantButtonTapped:(id)sender {
    ViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"dialpad"];
    vc.scene = 1;
    vc.dialPadViewDelegate = self;
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)changeScene:(NSInteger)scene {
    
    dispatch_async(dispatch_get_main_queue(), ^(){
        if (scene == 0) {
            // taxi
            self.imageeView.image = [UIImage imageNamed:@"hometaxi"];
        }
        if (scene == 1) {
            // restaurant
            self.imageeView.image = [UIImage imageNamed:@"homerestaurant"];
        }
        if (scene == 2) {
            // intro
            self.imageeView.image = [UIImage imageNamed:@"homeintro"];
        }
        
        [self.imageeView setNeedsDisplay];
    });
    
    
    
}

@end
